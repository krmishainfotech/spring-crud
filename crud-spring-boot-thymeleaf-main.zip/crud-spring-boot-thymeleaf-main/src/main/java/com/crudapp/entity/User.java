package com.crudapp.entity;

import java.io.File;
import java.sql.Date;
import java.text.SimpleDateFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="users")//, uniqueConstraints={@UniqueConstraint(columnNames ={"email"})})
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String name;	
	private Date dob;	
	private String email;	
	private String password;	
	private String image;
	private String gender;
	private String mobile;
	private String phone;
	private String state;
	private String city;
	private String hobbies;
	private boolean termsAccepted;

	public User() {}
	
	public User(String name, Date dob, String email, String password, String image) {
		super();
		
		this.name = name;
		this.dob = dob;
		this.email = email;
		this.password = password;
		this.image = image;
	}
	public User(String name, Date dob, String email, String password, String image,
				String gender, String mobile, String phone,
				String state, String city, String hobbies, boolean termsAccepted) {
		super();
		this.name = name;
		this.dob = dob;
		this.email = email;
		this.password = password;
		this.image = image;
		this.gender = gender;
		this.mobile = mobile;
		this.phone = phone;
		this.state = state;
		this.city = city;
		this.hobbies = hobbies;
		this.termsAccepted = termsAccepted;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getGender() { return gender; }
	public void setGender(String gender) { this.gender = gender; }

	public String getMobile() { return mobile; }
	public void setMobile(String mobile) { this.mobile = mobile; }

	public String getPhone() { return phone; }
	public void setPhone(String phone) { this.phone = phone; }

	public String getState() { return state; }
	public void setState(String state) { this.state = state; }

	public String getCity() { return city; }
	public void setCity(String city) { this.city = city; }

	public String getHobbies() { return hobbies; }
	public void setHobbies(String hobbies) { this.hobbies = hobbies; }

	public boolean isTermsAccepted() { return termsAccepted; }
	public void setTermsAccepted(boolean termsAccepted) { this.termsAccepted = termsAccepted; }


	public String getFormattedDob() {
		SimpleDateFormat d = new SimpleDateFormat("dd MMM yyyy");
		return d.format(dob);
	}
	public String getImageUrl() {
		
		if(image == null) {
			return "/images/user.png";
		}else {
			String UPLOAD_DIR = System.getProperty("user.dir") + "/src/main/resources/static/uploads/";				
			if(new File((UPLOAD_DIR + image.trim())).exists()) {
				 return "/uploads/" + image.trim();
			} 
			else {
				return"/images/user.png";
			}
		}
		
	
		
		
	}
	
}
