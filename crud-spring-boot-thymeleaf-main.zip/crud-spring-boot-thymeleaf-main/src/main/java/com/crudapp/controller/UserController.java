package com.crudapp.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.MediaTypeFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.crudapp.entity.User;
import com.crudapp.service.UserService;

@Controller
public class UserController {

	private UserService userService;
	private final String UPLOAD_DIR = System.getProperty("user.dir")
			+ "/src/main/resources/static/uploads/";

	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}

	@GetMapping("/")
	public String index() {
		return "index";
	}


	@GetMapping("/list")
	public String getUsersList(@RequestParam(defaultValue="1") Integer pageNo,
							   @RequestParam(defaultValue="5") Integer pageSize,
							   @RequestParam(value="name",   required=false) String name,
							   @RequestParam(value="gender", required=false) String gender,
							   @RequestParam(value="state",  required=false) String state,
							   Model model) {

		Page<User> page = userService.findFilteredUsers(pageNo, pageSize, name, gender, state);
		model.addAttribute("users", page.getContent());
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("currentPage", pageNo);

		model.addAttribute("nameFilter", name);
		model.addAttribute("genderFilter", gender);
		model.addAttribute("stateFilter", state);


		model.addAttribute("pageSize", pageSize);

		return "users";
	}


	@GetMapping("/new")
	public String createNewUser(Model model) {
		model.addAttribute("user", new User());
		return "create-new-user";
	}


	@PostMapping("/users")
	public String saveUser(@RequestParam("name") String name,
						   @RequestParam("gender") String gender,
						   @RequestParam("dob") Date dob,
						   @RequestParam(value="email", required=false) String email,
						   @RequestParam(value="mobile", required=false) String mobile,
						   @RequestParam(value="phone", required=false) String phone,
						   @RequestParam("state") String state,
						   @RequestParam(value="city", required=false) String city,
						   @RequestParam(value="hobbies", required=false) List<String> hobbies,
						   @RequestParam("password") String password,
						   @RequestParam(value="image", required=false) MultipartFile image,
						   @RequestParam("termsAccepted") boolean termsAccepted,
						   RedirectAttributes redirectAttributes
	) throws IOException {
		if ((mobile == null || mobile.trim().isEmpty()) &&
				(phone == null || phone.trim().isEmpty())) {
			redirectAttributes.addFlashAttribute("flashMessage",
					"You must fill in either Mobile or Phone!");
			return "redirect:/new";
		}

		String hobbiesStr = "";
		if (hobbies != null && !hobbies.isEmpty()) {
			hobbiesStr = String.join(",", hobbies);
		}

		String uploadedImage = userService.uploadImage(image);

		String encryptedPassword = userService.encryptPassword(password);

		User user = new User();
		user.setName(name);
		user.setGender(gender);
		user.setDob(dob);
		user.setEmail(email);
		user.setMobile(mobile);
		user.setPhone(phone);
		user.setState(state);
		user.setCity(city);
		user.setHobbies(hobbiesStr);
		user.setPassword(encryptedPassword);
		user.setImage(uploadedImage);
		user.setTermsAccepted(termsAccepted);

		userService.saveUser(user);

		return "/add-success";
	}

	@GetMapping("/home")
	public String goToHomePage() {
		return "index";
	}

	@GetMapping("/update/{id}")
	public String updateUser(@PathVariable("id") Long id, Model model) {
		model.addAttribute("user", userService.getUserById(id));
		return "update-user";
	}

	@PostMapping("/users/{id}")
	public String saveUpdatedUser(
			@PathVariable("id") Long id,
			@RequestParam("name") String name,
			@RequestParam("gender") String gender,
			@RequestParam("dob") Date dob,
			@RequestParam(value="email", required=false) String email,
			@RequestParam(value="mobile", required=false) String mobile,
			@RequestParam(value="phone", required=false) String phone,
			@RequestParam("state") String state,
			@RequestParam(value="city", required=false) String city,
			@RequestParam(value="hobbies", required=false) List<String> hobbies,
			@RequestParam("password") String password,
			@RequestParam(value="image", required=false) MultipartFile image,
			@RequestParam("oldImage") String oldImageName,
			@RequestParam("termsAccepted") boolean termsAccepted,
			RedirectAttributes redirectAttributes
	) throws IOException {

		if ((mobile == null || mobile.trim().isEmpty()) &&
				(phone == null || phone.trim().isEmpty())) {
			redirectAttributes.addFlashAttribute("flashMessage",
					"Mobile or Phone is required!");
			return "redirect:/update/" + id;
		}


		String hobbiesStr = "";
		if (hobbies != null && !hobbies.isEmpty()) {
			hobbiesStr = String.join(",", hobbies);
		}


		User user = userService.getUserById(id);
		if (user == null) {
			redirectAttributes.addFlashAttribute("flashMessage", "User not found!");
			return "redirect:/list";
		}

		String encryptedPassword = password.equals(user.getPassword())
				? password
				: userService.encryptPassword(password);

		String uploadedImage = userService.updateImage(oldImageName, image);

		user.setName(name);
		user.setGender(gender);
		user.setDob(dob);
		user.setEmail(email);
		user.setMobile(mobile);
		user.setPhone(phone);
		user.setState(state);
		user.setCity(city);
		user.setHobbies(hobbiesStr);
		user.setPassword(encryptedPassword);
		if (uploadedImage != null) {
			user.setImage(uploadedImage);
		}
		user.setTermsAccepted(termsAccepted);

		userService.updateUser(user);
		return "update-success";
	}

	@GetMapping("users/{id}")
	public String deleteUser(@PathVariable("id") Long id,
							 RedirectAttributes redirectAttributes) {
		userService.deleteUser(id);
		return "delete-success";
	}

	@GetMapping("/uploads/{imageName}")
	public ResponseEntity<Resource> getImage(@PathVariable String imageName) {
		try {
			Path imagePath = Paths.get(UPLOAD_DIR).resolve(imageName);
			Resource resource = new UrlResource(imagePath.toUri());
			if (resource.exists() && resource.isReadable()) {
				MediaType mediaType = MediaTypeFactory.getMediaType(resource)
						.orElse(MediaType.IMAGE_JPEG);
				return ResponseEntity.ok().contentType(mediaType).body(resource);
			} else {
				return ResponseEntity.notFound().build();
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}
}
