package com.crudapp.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;

import com.crudapp.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

    @Query("""
        SELECT u
        FROM User u
        WHERE 
          (:name IS NULL 
               OR TRIM(:name) = '' 
               OR LOWER(u.name) LIKE LOWER(CONCAT('%', :name, '%')))
          AND (:gender IS NULL 
               OR TRIM(:gender) = '' 
               OR u.gender = :gender)
          AND (:state IS NULL 
               OR TRIM(:state) = '' 
               OR u.state = :state)
    """)
    Page<User> filterUsers(
            @Param("name") String name,
            @Param("gender") String gender,
            @Param("state") String state,
            Pageable pageable
    );
}
